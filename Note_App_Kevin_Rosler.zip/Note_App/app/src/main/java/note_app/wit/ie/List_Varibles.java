package note_app.wit.ie;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class List_Varibles extends Super_Class implements AdapterView.OnItemClickListener {
    ListView listview;
    CustomAdapter adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listview = (ListView) findViewById(R.id.notelist);
        adapter = new CustomAdapter(this, notes.databasenote.getAll());
        if(!adapter.isEmpty()) {
            listview.setAdapter(adapter);
            listview.setOnItemClickListener(this);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        Toast.makeText(this,""+adapter.notelist.get(i),Toast.LENGTH_LONG).show();
    }
    //https://stackoverflow.com/questions/8166497/custom-adapter-for-list-view
    class CustomAdapter extends ArrayAdapter<NoteObjects> {
        private Context context;
        public List<NoteObjects> notelist;
        private String editDate = "";
        private String editLocation = "";
        private String editNote = "";


        public CustomAdapter(Context context, List<NoteObjects> notelist) {
            super(context, R.layout.content_change, notelist);
            this.context = context;
            this.notelist = notelist;
        }

        public boolean isValidDate(String text) {
            if (text == null || !text.matches("[0-3]\\d-[01]\\d-\\d{4}"))
                return false;
            SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
            df.setLenient(false);
            try {
                df.parse(text);
                return true;
            } catch (ParseException ex) {
                return false;
            }
        }

        public View getView(final int postion, final View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater)
                    context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View view = inflater.inflate(R.layout.content_change, parent, false);
            final NoteObjects noteObjects = notelist.get(postion);

            TextView date = view.findViewById(R.id.playdate);
            TextView location =  view.findViewById(R.id.playlocation);
            TextView note = view.findViewById(R.id.playnote);
            /////////Delete button****************************

            Button delete = view.findViewById(R.id.deleteButton);
            delete.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(List_Varibles.this);
                    builder.setTitle("Delete Note?");
                    builder.setCancelable(true);
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            notes.databasenote.deleteOneItem(notelist.get(postion).getId());
                            startActivity(getIntent());

                        }

                    });

                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }

                    });
                    builder.show();
                }
            }); //https://stackoverflow.com/questions/45304307/cant-get-the-id-from-listview-right/45304344#45304344



            Button edit = (Button) view.findViewById(R.id.editButton);

            edit.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(List_Varibles.this);
                    builder.setTitle("Edit Date/Location/Note");

                    final EditText date = new EditText(List_Varibles.this);
                    date.setInputType(InputType.TYPE_CLASS_TEXT);
                    date.setHint("Date"); //https://stackoverflow.com/questions/8922587/how-to-give-the-hint-of-edittextbox-of-dialog-which-is-created-by-code-in-androi

                    final EditText location = new EditText(List_Varibles.this);
                    location.setInputType(InputType.TYPE_CLASS_TEXT);
                    location.setHint("Location");

                    final EditText note = new EditText(List_Varibles.this);
                    note.setInputType(InputType.TYPE_CLASS_TEXT);
                    note.setHint("Note");

                    LinearLayout alertLayout = new LinearLayout(List_Varibles.this);
                    alertLayout.setOrientation(LinearLayout.VERTICAL);
                    alertLayout.addView(date);
                    alertLayout.addView(location);
                    alertLayout.addView(note);
                    builder.setView(alertLayout); //https://stackoverflow.com/questions/16169787/how-to-add-two-edit-text-fields-or-views-in-an-alertdialog-box

                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            editDate = date.getText().toString();
                            editLocation = location.getText().toString();
                            editNote = note.getText().toString();

                            if (editDate.equals("") || !isValidDate(editDate)) {
                                editDate = notelist.get(postion).getDate();
                            }
                            if (editLocation.equals("")) {
                                editLocation = notelist.get(postion).getLocation();
                            }
                            if (editNote.equals("")) {
                                editNote = notelist.get(postion).getNote();
                            }




                            notes.databasenote.geteditText(notelist.get(postion).getId(), editDate, editLocation, editNote);
                            startActivity(getIntent());//https://stackoverflow.com/questions/5099814/knowing-when-edit-text-is-done-being-edited


                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                    builder.show();

                }//https://stackoverflow.com/questions/10903754/input-text-dialog-android
            });//https://stackoverflow.com/questions/2115758/how-do-i-display-an-alert-dialog-on-android

            date.setText(noteObjects.date);
            location.setText(noteObjects.location);
            note.setText(noteObjects.note);
            return view;
        }


    }
}



