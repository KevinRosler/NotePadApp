package note_app.wit.ie;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SearchDate extends Super_Class {
    private EditText searchitem;
    public TextView Results;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date);

        searchitem = (EditText) findViewById(R.id.searchdate);
        Results = (TextView) findViewById(R.id.printResults);

    }//https://stackoverflow.com/questions/29305870/how-to-implement-the-search-function-in-android

    public void searchdateButtonPressed(View view){
        String search = searchitem.getText().toString();
        notes.databasenote.searchbydate(search, Results);

    }

}
