package note_app.wit.ie;

public class NoteObjects {
    public int id;
    public String date;
    public String location;
    public String note;

    public NoteObjects(){
        this.date="";
        this.location="";
        this.note="";
    }
    public NoteObjects(String date){
        this.date= date;
        this.location="";
        this.note="";
    }

    public NoteObjects(String date, String location){
        this.date= date;
        this.location=location;
        this.note="";
    }
    public NoteObjects(String date, String location, String note){
        this.date= date;
        this.location=location;
        this.note= note;
    }

    public int getId(){
        return id;
    }
    public String getDate() {
        return date;
    }
    public String getLocation() {
        return location;
    }
    public String getNote() {
        return note;
    }

    public String toString() {return id +" , "+date+" , "+location+" , "+note;}
}

