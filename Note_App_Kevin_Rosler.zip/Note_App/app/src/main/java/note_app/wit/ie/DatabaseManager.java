package note_app.wit.ie;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    private SQLiteDatabase database;
    private Database databaseclass;


    public DatabaseManager(Context context) {
        databaseclass = new Database(context);
    }

    public void open() throws SQLException {
        database = databaseclass.getWritableDatabase();
    }

    public void close() {
        database.close();
    }

    public void add(NoteObjects date) {
        ContentValues values = new ContentValues();
        values.put("date", date.date);
        values.put("location", date.location);
        values.put("note",date.note);

        database.insert("notepad", null, values);
    }

    public List<NoteObjects> getAll() {
        List<NoteObjects> notepad  = new ArrayList<NoteObjects>();
        Cursor cursor = database.rawQuery("SELECT * FROM notepad", null);
        cursor.moveToFirst();

        while (!cursor.isAfterLast()) {
            NoteObjects date = toDate(cursor);
            notepad.add(date);
            cursor.moveToNext();
        }
        cursor.close();
        return notepad;
    }

    private NoteObjects toDate(Cursor cursor) {
        NoteObjects object = new NoteObjects();
        object.id = cursor.getInt(0);
        object.date = cursor.getString(1);
        object.location = cursor.getString(2);
        object.note = cursor.getString(3);

        return object;
    }

    public void setNoteTotal(Super_Class smmObject) {
        Cursor cursor = database.rawQuery("SELECT COUNT(date) FROM notepad", null);
        cursor.moveToFirst();

        if (!cursor.isAfterLast())
            smmObject.notes.notetotal = cursor.getInt(0);
    }

    public void searchbydate(String searchitem, TextView Results) {

        Cursor cursor = database.rawQuery("SELECT * FROM notepad WHERE LOWER(date) = '" + searchitem.toLowerCase().trim() + "' ", null);
        StringBuffer results = new StringBuffer();

        if (cursor.getCount() != 0) {
            while (cursor.moveToNext()) {
                results.append("Date: " + cursor.getString(1)+ ", ");
                results.append("Location: " + cursor.getString(2)+ ", ");
                results.append("Note: " + cursor.getString(3)).append("\n");
                Results.setText(results.toString());

            }
            cursor.close();
        } else {
            Results.setText("No Notes Found");
        }//https://www.codeproject.com/Articles/783073/A-Simple-Android-SQLite-Example
    }

    public void searchbylocation(String searchitem, TextView showResults) {

        Cursor cursor = database.rawQuery("SELECT * FROM notepad WHERE LOWER(location) = '" + searchitem.toLowerCase().trim() + "' ", null);
        StringBuffer results = new StringBuffer();

        if (cursor.getCount() != 0) {
            while (cursor.moveToNext()) {
                results.append("Date: " + cursor.getString(1)+ ", ");
                results.append("Location: " + cursor.getString(2)+ ", ");
                results.append("Note: " + cursor.getString(3)).append("\n");
                showResults.setText(results.toString());
            }
            cursor.close();
        } else {
            showResults.setText("No Notes Found");
        }//^^
    }

    public void deleteOneItem(int id) {

        database.delete("notepad", "id" + "=" + id, null);

    }


    public void delete() {

        database.delete("notepad", null, null);

    }

    public void geteditText(int id, String editdate, String editlocation, String editnote) {
        database.execSQL("UPDATE notepad SET date = '"+editdate+"', location = '"+editlocation+"', note = '"+editnote+"' WHERE id = "+ id);




    }
}




