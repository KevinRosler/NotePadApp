package note_app.wit.ie;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class NoteActivity extends Super_Class {

    private TextView noteinsert;

    private EditText adddate;
    private EditText addlocation;
    private EditText addnote;
    private Button addButton;
    int total;
    String dateadd;
    String locationadd;
    String noteadd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        noteinsert=(TextView)findViewById(R.id.total2);
        adddate=(EditText)findViewById(R.id.enterdate);
        addlocation = (EditText)findViewById(R.id.enterlocation);
        addnote = (EditText)findViewById(R.id.enternote);
        addButton = (Button)findViewById(R.id.addbutton);
        noteinsert.setText("");
        total =+ notes.notetotal;
        noteinsert.setText(Integer.toString(total));
    }

    public void addButtonPressed(View view){
        dateadd = adddate.getText().toString().trim();
        locationadd = addlocation.getText().toString().trim();
        noteadd = addnote.getText().toString().trim();

        if(dateadd.equals("") || !isValidDate(dateadd)){
            Toast.makeText(this,"Please enter a Date in format DD-MM-YYYY",Toast.LENGTH_LONG).show();
        }
        else if(locationadd.equals("")) {
            Toast.makeText(this, "Please enter in your Location", Toast.LENGTH_LONG).show();
        }
        else{
            notes.newNoteOjects(new NoteObjects(dateadd,locationadd,noteadd));
            total =+notes.notetotal;
            noteinsert.setText(Integer.toString(total));

            clearTextFields();
        }

    }


      // https://stackoverflow.com/questions/2149680/regex-date-format-validation-on-java [Accessed 2 Mar. 2018].

    public static boolean isValidDate(String text) {
        if (text == null || !text.matches("[0-3]\\d-[01]\\d-\\d{4}"))
            return false;
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        df.setLenient(false);
        try {
            df.parse(text);
            return true;
        } catch (ParseException ex) {
            return false;
        }
    }


    public void clearTextFields() {
        adddate.setText("");
        addlocation.setText("");
        addnote.setText("");
        Toast.makeText(this,"Note Added",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void delete(MenuItem item){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("This will Delete all Data, Are you sure you want to DELETE everything?");
        builder.setCancelable(true);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {


            @Override
            public void onClick(DialogInterface dialog, int which) {
                notes.databasenote.delete();
                notes.notetotal=0;
                noteinsert.setText(""+notes.notetotal);

            }

        });

        builder.setNegativeButton("No",new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int which){
                dialog.cancel();
            }

        });
        builder.show();


    }//https://stackoverflow.com/questions/2115758/how-do-i-display-an-alert-dialog-on-android
}