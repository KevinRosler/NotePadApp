package note_app.wit.ie;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class Super_Class extends AppCompatActivity {
    public NoteCentre notes;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Application app = getApplication();
        notes = (NoteCentre) app;
        notes.databasenote.open();
        notes.databasenote.setNoteTotal(this);
    }

    protected void onDestroy(){
        super.onDestroy();
        notes.databasenote.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_note,menu);
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        MenuItem home = menu.findItem(R.id.action_menu);
        MenuItem list = menu.findItem(R.id.action_list);
        MenuItem location = menu.findItem(R.id.action_searchlocation);
        MenuItem date = menu.findItem(R.id.action_searchdate);
        MenuItem deleteall = menu.findItem(R.id.action_deleteall);

        if(notes.databasenote.getAll().isEmpty()){
            list.setEnabled(false);
            deleteall.setEnabled(false);
            location.setEnabled(false);
            date.setEnabled(false);

        }else{
            list.setEnabled(true);
            deleteall.setEnabled(true);
            location.setEnabled(true);
            date.setEnabled(true);

        }

        if (this instanceof NoteActivity){
            deleteall.setVisible(true);
        }else {
            deleteall.setVisible(false);
        }

        return true;
    }

    @Override

    public void onBackPressed(){
        startActivity(new Intent(this, NoteActivity.class));
        //https://stackoverflow.com/questions/29841747/app-crashes-when-i-hit-the-back-button
    }


    public void list(MenuItem item){
        startActivity(new Intent(this, List_Varibles.class));
    }

    public void delete(MenuItem item){

    }
    public void searchdate(MenuItem item){
        startActivity(new Intent(this, SearchDate.class));
    }
    public void searchlocation(MenuItem item){
        startActivity(new Intent(this, SearchLocation.class));
    }
    public void home(MenuItem item){
        startActivity(new Intent(this, NoteActivity.class));

    }



    //
    public void showWarning() {
        Toast.makeText(this,"Please enter a valid Date Format",Toast.LENGTH_LONG).show();
    }
}
