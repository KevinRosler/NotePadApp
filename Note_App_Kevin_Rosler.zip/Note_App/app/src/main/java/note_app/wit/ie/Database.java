package note_app.wit.ie;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


    public class Database extends SQLiteOpenHelper {
        //https://developer.android.com/reference/android/database/sqlite/SQLiteDatabase
        private static final String DATABASE_NAME = "notepad.db";
        private static final int DATABASE_VERSION =10;
        private static final String DATABASE_CREATE_TABLE_NOTE = "create table notepad"+
                "( id integer primary key autoincrement not null,"+
                "date text not null,"+
                "location text not null,"+
                "note text not null);";

        public Database(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }


        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL(DATABASE_CREATE_TABLE_NOTE);
            sqLiteDatabase.execSQL("insert into notepad values(1, '12-05-2018', 'Waterford', 'Exams')");
            sqLiteDatabase.execSQL("insert into notepad values(2, '12-06-2018', 'Wexford', 'Walk dog')");
            sqLiteDatabase.execSQL("insert into notepad values(3, '12-07-2018', 'Limmerick', 'Walk teacher')");
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            Log.w(Database.class.getName(), "Upgrading database from " + i + "to version "+ i1);
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS notepad");
            onCreate(sqLiteDatabase);

        }
    }

