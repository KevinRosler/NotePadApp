package note_app.wit.ie;

import android.app.Application;
import android.util.Log;

public class NoteCentre extends Application{
    public int notetotal = 0;
    public DatabaseManager databasenote;

    public int newNoteOjects(NoteObjects date) {
        databasenote.add(date);
        notetotal++;
        return notetotal;
    }

    public void onCreate(){
        super.onCreate();
        Log.v("LogMessage","NoteCentreClass");
        databasenote = new DatabaseManager(this);
        Log.v("LogMessage","Database created");
    }

}

